/****************************************************************************
 * math1.c
 *
 * Ci�ncia da Computa��o 50
 * Gabriel Lima Guimar�es
 *
 * Computa uma soma mas n�o faz nada com ela
 *
 * Demonstra o uso de aritm�tica computacional
 ***************************************************************************/

#include <stdio.h>

int
main(void)
{
    int x = 1;
    int y = 2;
    int z = x + y;
}
