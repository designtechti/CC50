/****************************************************************************
 * math2.c
 *
 * Ci�ncia da Computa��o 50
 * Gabriel Lima Guimar�es
 *
 * Computa uma soma e imprime o resultado
 *
 * Demonstra o uso de printf com vari�veis
 ***************************************************************************/

#include <stdio.h>

int
main(void)
{
    int x = 1;
    int y = 2;
    int z = x + y;
    printf("%d", z);
}
