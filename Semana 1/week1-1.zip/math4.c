/****************************************************************************
 * math4.c
 *
 * Ci�ncia da Computa��o 50
 * Gabriel Lima Guimar�es
 *
 * Computa e imprime uma opera��o com floats.
 *
 * Demonstra o uso de casting.
 ***************************************************************************/

#include <stdio.h>

int
main(void)
{
    float answer = 17 / (float) 13;
    printf("%.2f\n", answer);
}
